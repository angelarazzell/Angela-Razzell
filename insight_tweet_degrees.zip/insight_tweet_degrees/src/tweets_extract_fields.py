"""loads the json tweet messages, removes rate limiting messages"""
"""extracts the 2 necessary fields: "created_at", "hashtags" """
"""finally, loads the tweets extracted fields into a much smaller text file"""

import json
import os

par_dir = os.path.abspath(os.path.join(os.getcwd(), os.pardir))

with open(os.path.join(par_dir,'tweet_input','tweets.txt'),'r') as fin, \
    open(os.path.join(par_dir,'tweet_input','tweets_extract.txt'),'w') as fout:

    for line in fin:
        tweet = json.loads(line)

        """if "limit" in tweet:"""
        """changed to "entities" to prevent other errors from bad line input"""
        if "entities" not in tweet:
            continue
        
        ents = tweet.get("entities") 
        hashtags = ents.get("hashtags")

        """append only hashtags (text) from the hashtags field, ignore the indices"""
        hashlist = []
        for i, _ in enumerate(hashtags):
            hashlist.append(hashtags[i]["text"])

        hashtag_data = {"created_at" : tweet.get("created_at"), "hashtags" : hashlist}

        """write only hashtags and created_at fields to tweets_extract in input file"""
        fout.write(json.dumps(hashtag_data)+'\n')
        
