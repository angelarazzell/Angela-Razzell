from __future__ import division

import json
import os

from datetime import datetime, timedelta
from dateutil.parser import parse
from itertools import permutations

def cutoff(time_list, interval):
    """return the minimum acceptable time for the current time window"""
    """(maximum time in the list) - 59 seconds"""
    return max(time_list) - timedelta(seconds=interval)

def degreecalc(edges_list,nodes_list):
    """returns the average degree of a vertex in a Twitter hashtag graph"""
    noedges = len(set(edges_list))
    nonodes = len(set(nodes_list))
    try: 
        return (noedges / nonodes)
    except ZeroDivisionError:
        return (noedges / 1)

delta = 59
tweet = {}
time_list = []
httuple_list = []
par_dir = os.path.abspath(os.path.join(os.getcwd(), os.pardir))

with open(os.path.join(par_dir,'tweet_input','tweets_extract.txt'),'r') as fin, \
     open(os.path.join(par_dir,'tweet_output','output.txt'),'w') as fout:

    for line in fin:
        tweet[line] = json.loads(line)
        
        time = parse(tweet[line].get("created_at"))
        time_list.append(time)
        mintime = cutoff(time_list, delta)
        hashtag_tweet = tweet[line].get("hashtags")

        httuple_list.append((time, hashtag_tweet))
        
        """ignores hashtag lists with 0 or 1 hashtags"""
        """ignores entries if created_at time < cutoff time"""
        """appends the rest of the hashtags to a list"""
        hashtags_slider = []
        for (t,h) in httuple_list:
            if len(h) < 2:
                continue
            elif t < mintime:
                continue
            hashtags_slider.append(h)

        """for graph nodes: use each hashtag per tweet"""
        """for graph edges: permutate the hashtags per tweet into tuples"""
        """concatenate both of the above for totals per time window"""
        allnodes = []
        alledges = []
        for i, _ in enumerate(hashtags_slider):
            allnodes.extend(hashtags_slider[i])
        
            hashtag_tuples = permutations(hashtags_slider[i], 2)            
            alledges.extend(tuple(hashtag_tuples))

        average_degree = degreecalc(alledges,allnodes)
        
        fout.write("%.2f" % average_degree + "\n")
